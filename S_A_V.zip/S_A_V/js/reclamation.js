function saisie(){

    if((document.getElementById("num_rec").value=='')||(document.getElementById("objet_rec").value=='')||(document.getElementById("message_rec").value==''))
    {alert('veuillez remplir tous les chemps');}
}

function CheckNum() {

    var num = document.getElementById("num_rec").value;
    ch = num.substr(0, 1);
    var error= document.getElementById("message");
    
    
    if (num.length ==8 ) {
        for (i=0;i<num.length;i++) {
               
                if ( num.charAt(i)>"0" || num.charAt(i)<"9" )  {
                    error.innerHTML="";
                    return true;
                }
                else if ( (ch == "2") || (ch == "5") || (ch == "9") )  {
                   error.innerHTML="";
                    return true;
                }
                else {
                     error.innerHTML="Numéro de tél en tunisie svp.";
                    return false;
                }
            }
    }
    
    else {
        error.innerHTML="Numéro de tél > 8 ou pas en Tunisie.";
        return false;
    }
    
    }
    