<!DOCTYPE html>
<html lang="en">

<head>
    <!-- premiere etape -->

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reclamation</title>

    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">

    

    <!-- All css files are included here. -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Owl Carousel min css -->
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="css/core.css">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="css/shortcode/shortcodes.css">
    <!-- Theme main style -->
    <link rel="stylesheet" href="style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- User style -->
    <link rel="stylesheet" href="css/custom.css">


    <!-- Modernizr JS -->
    <script src="js/vendor/modernizr-3.5.0.min.js"></script>
</head>

<body>
<?php require('header.php')?>

     <!-- Start Bradcaump area -->
     <div class="ht__bradcaump__area" style="background: rgba(0, 0, 0, 0) url(images/bg/4.jpg) no-repeat scroll center center / cover ;">
        <div class="ht__bradcaump__wrap">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="bradcaump__inner">
                            <nav class="bradcaump-inner">
                              <a class="breadcrumb-item" href="index.html">Home</a>  <!-- //ajouter lien pour home page -->
                              <span class="brd-separetor"><i class="zmdi zmdi-chevron-right"></i></span>
                              <span class="breadcrumb-item active">Reclamation</span>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Bradcaump area -->

    <!-- Start Contact Area -->
    <section class="htc__contact__area ptb--100 bg__white">
        <div class="container">
            <div class="row">
                <div class="contact-form-wrap mt--60">
                    <div class="col-xs-12">
                        <div class="contact-title">
                            <h2 class="title__line--6">Reclamation</h2>
                        </div>
                    </div>
                    <div class="col-xs-12">
                        <form id="contact-form" method="post" action="ajouterReclamation.php" >
                        <div class="single-contact-form">
                                <div class="contact-box subject">
                                    <input type="number" name="id_client" id="id_client" placeholder="Id client*">
                                </div>
                            </div>
                            <div class="single-contact-form">
                                <div class="contact-box name">
                                    <input type="date" name="date_rec" id="date_rec" placeholder=" Date*" value="<?PHP echo  date("Y/m/d") ?>" >
                                    <input type="number" name="num_rec" id="num_rec" onblur="CheckNum()" placeholder="Numero Telephone*">
                                </div>
                            </div>
                           
                            <div class="single-contact-form">
                                <div class="contact-box subject">
                                    <input type="text" name="objet_rec" id="objet_rec" placeholder="Objet*">
                                    
                                </div>
                            </div>
                            <div class="single-contact-form">
                                <div class="contact-box message">
                                    <textarea name="message_rec" id="message_rec" placeholder="Message"></textarea>
                                </div>
                            </div>
                            <div class="contact-btn">
                                <button type="submit" class="fv-btn" id="envoyer" onclick="saisie()" >envoyer</button>
                            </div>
                        </form>
                        <div class="form-output">
                            <p class="form-messege" id="message" style="color:#b7a868;" ></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Contact Area -->
    <!-- End Banner Area -->
    <?php require('footer.php')?> 
    
    <!-- Placed js at the end of the document so the pages load faster -->

    <!-- jquery latest version -->
    <script src="js/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap framework js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- All js plugins included in this file. -->
    <script src="js/plugins.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/ajax-mail.js"></script>

    <script src="js/reclamation.js"></script>


</body>

</html>
