<?PHP
	include "entities/reclamation.php";
    include "core/reclamationC.php";


	if (isset($_POST['date_rec']) and isset($_POST['num_rec']) and isset($_POST['objet_rec']) and isset($_POST['message_rec']) and isset($_POST['id_client'])){
        $reclamation1=new Reclamation($_POST['date_rec'],$_POST['num_rec'],$_POST['objet_rec'],$_POST['message_rec'],"en attente",$_POST['id_client']);
		$reclamation1C=new ReclamationCore();
		$reclamation1C->ajouterReclamation($reclamation1);
		//header('Location: afficherEmploye.php');
		
	}
	else{
		echo "vérifier les champs";
	}
?>