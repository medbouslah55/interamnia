<?php
class Reclamation{

    //private $id_reclamation;
    private $date_reclamation;
    private $num_reclamation;
    private $objet_reclamation;
    private $message_reclamation;
    private $etat_reclamation;
    private $id_client;

    function __construct($date_rec,$num_rec,$objet_rec,$message_rec,$etat_rec,$id_client){
       // $this->id_reclamation=$id_rec;
        $this->date_reclamation=$date_rec;
        $this->num_reclamation=$num_rec;
        $this->objet_reclamation=$objet_rec;
        $this->message_reclamation=$message_rec;
        $this->etat_reclamation=$etat_rec;
        $this->id_client=$id_client;

    }

    /*function getId(){
        return $this->id_reclamation;
    }
    function setId($id_reclamation){
        $this->id_reclamation=$id_reclamation;
    }*/

    function getDate(){
        return $this->date_reclamation;
    }
    function setDate($date_reclamation){
        $this->date_reclamation=$date_reclamation;
    }

    function getNum(){
        return $this->num_reclamation;
    }
    function setNum($num_reclamation){
        $this->num_reclamation=$num_reclamation;
    }

    function getObjet(){
        return $this->objet_reclamation;
    }
    function setObjet($objet_reclamation){
        $this->objet_reclamation=$objet_reclamation;
    }

    function getMessage(){
        return $this->message_reclamation;
    }
    function setMessage($message_reclamation){
        $this->message_reclamation=$message_reclamation;
    }

    function getEtat(){
        return $this->etat_reclamation;
    }
    function setEtat($etat_reclamation){
        $this->etat_reclamation=$etat_reclamation;
    }

    function getId_client(){
        return $this->id_client;
    }
    function setId_client($id_client){
        $this->id_client=$id_client;
    }
}
?>