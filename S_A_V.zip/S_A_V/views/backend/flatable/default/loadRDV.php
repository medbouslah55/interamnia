<?php

//load.php

$connect = new PDO('mysql:host=localhost;dbname=projet_web_final', 'root', 'root');

$data = array();

$query = "SELECT * FROM rdv ORDER BY id_rdv";

$statement = $connect->prepare($query);

$statement->execute();

$result = $statement->fetchAll();

foreach($result as $row)
{
 $data[] = array(
  'id'   => $row["id_rdv"],
  'title'   => $row["object_rdv"],
  'start'   => $row["date_start_rdv"],
  'end'   => $row["date_end_rdv"]
 );
}

echo json_encode($data);

?>