<?php

//update.php

$connect = new PDO('mysql:host=localhost;dbname=projet_web_final', 'root', 'root');

if(isset($_POST["id"]))
{
 $query = "
 UPDATE rdv 
 SET object_rdv=:title, date_start_rdv=:start_event, date_end_rdv=:end_event 
 WHERE id_rdv=:id
 ";
 $statement = $connect->prepare($query);
 $statement->execute(
  array(
   ':title'  => $_POST['title'],
   ':start_event' => $_POST['start'],
   ':end_event' => $_POST['end'],
   ':id'   => $_POST['id']
  )
 );
}

?>