<?PHP
include "../../../../core/reclamationC.php";
$reclamationC=new ReclamationCore();
if (isset($_POST["id_reclamation"])){
    $reclamationC->traiterReclamation($_POST["id_reclamation"]);
    header('Location: Reclamation_back.php');
}

?>