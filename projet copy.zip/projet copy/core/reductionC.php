<?PHP
	
	class ReductionC extends PromotionC{
        /*
		function afficherreduction ($reduction){
			echo "id: ".$reduction->getid()."<br>";
			echo "Nom: ".$reduction->getNom()."<br>";
			echo "Prénom: ".$reduction->getdatef()."<br>";
			echo "tarif heure: ".$reduction->getTarifHoraire()."<br>";
			echo "nb heures: ".$reduction->getNbHeures()."<br>";
        }
        */


		
        function ajouterReduction($reduction)
        {  
			$sql="insert into reduction (id_reduction,pourcentage_reduction,id_prodred) 
			values (:id, :pourcentage , :idprod)";
			
			$db = config::getConnexion();
			
			try{
				
				$id=parent::ajouterPromotion($reduction);
				

				$req=$db->prepare($sql);
				
				
				$p=$reduction->getPourcentage();
				$prod=$reduction->getProduit();
				
				
				$req->bindValue(':id',$id);
				$req->bindValue(':pourcentage',$p);
				$req->bindValue(':idprod',$prod);
				
				
			
				$req->execute();
			
			}
			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}
			
        }
        

      //jointure seulement fel classe fille?
      //supprimer du promo
		
        function afficherReductions()
        {
			
			$sql="SElECT p.id_promotion, p.date_deb, p.date_fin ,r.pourcentage_reduction ,r.id_prodred FROM reduction r INNER JOIN promotion p ON (p.id_promotion=r.id_reduction)";
			$db = config::getConnexion();
			try{
				$liste=$db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}	
		}
		







        function afficherReductionsfront()
        {
			
			$sql="SElECT p.id_promotion, p.date_deb, p.date_fin ,r.pourcentage_reduction ,r.id_prodred,pr.nom_produit ,pr.photo_produit ,pr.quantite_produit,pr.prix_produit FROM reduction r , promotion p,produits pr WHERE(p.id_promotion=r.id_reduction) and pr.id_produit=r.id_prodred";
			$db = config::getConnexion();
			try{
				$liste=$db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}	
        }



        



        function supprimerReduction($id)
        {   
			$sql="DELETE FROM reduction where id_reduction= :id";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':id',$id);
			try{
				$req->execute();
				parent::supprimerPromotion($id);
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
			
        }
        




        function modifierReduction($reduction, $id)
        {     parent::modifierPromotion($reduction, $id);
			$sql="UPDATE reduction SET pourcentage_reduction=:pourcentage , id_prodred=:prod WHERE id_reduction=:id";
			
			
			
			$db = config::getConnexion();
			try{		
				$req=$db->prepare($sql);
				
				$pourcentage=$reduction->getPourcentage();
				$prod=$reduction->getProduit();
				var_dump($prod);

				$req->bindValue(':id',$id);
				
				$datas = array(':id'=>$id, ':pourcentage'=>$pourcentage, ':prod'=>$prod);
				
				
				$req->bindValue(':pourcentage',$pourcentage);
				$req->bindValue(':prod',$prod);
				
				
			
				$req->execute();
				echo $req->rowCount() . " records UPDATED successfully";
				
			}
			catch (PDOException $e){
				echo " Erreur ! ".$e->getMessage();
				echo " Les datas : " ;
				print_r($datas);
			}
        }
        

   //a verifier comme afficher

        function recupererReduction($id)
        {
			$sql="SElECT p.id_promotion, p.date_deb, p.date_fin ,r.pourcentage_reduction ,r.id_prodred FROM reduction r INNER JOIN promotion p ON (p.id_promotion=r.id_reduction) where id_reduction=$id";
			$db = config::getConnexion();
			try{
				$liste=$db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
        
        


   
        function rechercherListeReductions($id)
        {
			$sql="SELECT p.id_promotion, p.date_deb, p.date_fin ,r.pourcentage_reduction ,r.id_prodred FROM reduction r INNER JOIN promotion p ON (p.id_promotion=r.id_reduction) where id_promotion like '%$id%'";
			$db = config::getConnexion();
			try{
				$liste=$db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
        }
        

	
		function afficherReductionstridate()
        {
			
			$sql="SElECT p.id_promotion, p.date_deb, p.date_fin ,r.pourcentage_reduction ,r.id_prodred FROM reduction r INNER JOIN promotion p ON (p.id_promotion=r.id_reduction) order by p.date_fin";
			$db = config::getConnexion();
			try{
				$liste=$db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}	
		}
		



		function afficherReductionstrip()
        {
			
			$sql="SElECT p.id_promotion, p.date_deb, p.date_fin ,r.pourcentage_reduction ,r.id_prodred FROM reduction r INNER JOIN promotion p ON (p.id_promotion=r.id_reduction) order by r.pourcentage_reduction";
			$db = config::getConnexion();
			try{
				$liste=$db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}	
        }


	function afficherProduits(){
            
		$sql="SElECT * From produits";
		$db = config::getConnexion();
		try{
			$liste=$db->query($sql);
			return $liste;
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}




	function statReduction(){
            
		$sql="SElECT id_prodred, count(*) as total from reduction group by id_prodred limit 10";
		$db = config::getConnexion();
		try{
			$liste=$db->query($sql);
			return $liste;
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}




	function statReductiong(){
            
		$sql="SElECT id_prodred, count(*) as total from reduction group by id_prodred order by count(*) desc limit 1 ";
		$db = config::getConnexion();
		try{
			$liste=$db->query($sql);
			return $liste;
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}

	




	function statReductiono(){
            
		$sql="SElECT p.id_promotion, p.date_deb,r.pourcentage_reduction ,r.id_prodred,pr.nom_produit FROM reduction r , promotion p,produits pr WHERE(p.id_promotion=r.id_reduction) and pr.id_produit=r.id_prodred order by p.date_deb limit 1 ";
		$db = config::getConnexion();
		try{
			$liste=$db->query($sql);
			return $liste;
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}






	function calendarReduction(){
            
		$sql="SElECT p.id_promotion,r.id_prodred, p.date_deb, p.date_fin FROM reduction r INNER JOIN promotion p ON (p.id_promotion=r.id_reduction)";
		$db = config::getConnexion();
		try{
			$liste=$db->query($sql);
			return $liste;
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}

	}

?>
