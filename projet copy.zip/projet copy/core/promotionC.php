
<?PHP
	include "../config.php";
	class PromotionC {
       


		
        function ajouterPromotion($promotion)
        {
			$sql="insert into promotion (date_deb,date_fin) 
			values (:dated,:datef)";
			$db = config::getConnexion();
			try{
				$req=$db->prepare($sql);
				
				
				$dated=$promotion->getDatedep();
				$datef=$promotion->getDatefin();
				
				
				$req->bindValue(':dated',$dated);
				$req->bindValue(':datef',$datef);
				
			  
				$req->execute();
				$Promo = $db->query("select id_promotion from promotion where id_promotion=(SELECT LAST_INSERT_ID())");
                foreach($Promo as $p){
                    $id_Promo = $p['id_promotion'];
                }
				
				
				return $id_Promo;
			
			}
			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}
			
        }
        


		
        function afficherPromotions()
        {
			
			$sql="SElECT * From promotion";
			$db = config::getConnexion();
			try{
				$liste=$db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}	
        }
        



        function supprimerPromotion($id)
        {
			$sql="DELETE FROM promotion where id_promotion= :id";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':id',$id);
			try{
				$req->execute();
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
        }
        




        function modifierPromotion($promotion, $id)
        {
			$sql="UPDATE promotion SET date_deb=:dated, date_fin=:datef WHERE id_promotion=:id";
			
			
			$db = config::getConnexion();
			try{		
				//echo "444";
				//var_dump($promotion);
				$req=$db->prepare($sql);
				
				
                //var_dump($idd);
                //var_dump($id);
				$dated=$promotion->getDatedep();
				//echo "410";
				$datef=$promotion->getDatefin();
				
				
				$req->bindValue(':id',$id);
				
				$datas = array( ':id'=>$id, ':dated'=>$dated,':datef'=>$datef);
				
				
				$req->bindValue(':dated',$dated);
				$req->bindValue(':datef',$datef);
				
               

			
				$req->execute();
				echo $req->rowCount() . " records UPDATED successfully";
				
			}
			catch (PDOException $e){
				echo " Erreur ! ".$e->getMessage();
				echo " Les datas : " ;
				print_r($datas);
			}
        }
        



        function recupererPromotion($id)
        {
			$sql="SELECT * from promotion where id_promotion=$id";
			$db = config::getConnexion();
			try{
				$liste=$db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
        
        


   /*
        function rechercherListePromotions($tarif)
        {
			$sql="SELECT * from promotion where tarifHoraire=$tarif";
			$db = config::getConnexion();
			try{
				$liste=$db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
        }
        

     */

	}

?>
