<?php
	


class ReclamationCore{

    function ajouterReclamation($Reclamation){
        $sql="INSERT INTO reclamation (date_reclamation, num_reclamation, objet_reclamation, message_reclamation, etat_reclamation, id_client) VALUES (:date_rec,:num_rec,:objet_rec,:message_rec,:etat_rec,:id_client)";
		$db = config::getConnexion();
		try{
            $req=$db->prepare($sql);
        
            $date=$Reclamation->getDate();
            $num=$Reclamation->getNum();
            $objet=$Reclamation->getObjet();
            $message=$Reclamation->getMessage();
            $etat=$Reclamation->getEtat();
            $id_client=$Reclamation->getId_client();
        
            $req->bindValue(':date_rec',$date);
            $req->bindValue(':num_rec',$num);
            $req->bindValue(':objet_rec',$objet);
            $req->bindValue(':message_rec',$message);
            $req->bindValue(':etat_rec',$etat);
            $req->bindValue(':id_client',$id_client);    
            
            $req->execute();
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }   
}

function afficherReclamations(){

        $sql="SElECT * From reclamation r inner join client c on r.id_client= c.id_client";
        //$sql = "SElECT * FROM demande d ORDER BY DATE_DEMANDE DESC";
        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }
function traiterReclamation($id_r){
        $sql = "UPDATE reclamation SET etat_reclamation= 'Traiter' where id_reclamation= :id_r";
        $db = config::getConnexion();
        $req = $db->prepare($sql);

        $req->bindValue(':id_r', $id_r);
        try {
            $req->execute();

        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }
function supprimerReclamation($id_r){
    $sql = "DELETE FROM reclamation where id_reclamation= :id_r";
    $db = config::getConnexion();
        $req = $db->prepare($sql);

        $req->bindValue(':id_r', $id_r);
        try {
            $req->execute();

        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }
function rechercheReclamation($rech){

    $sql="SELECT id_reclamation,id_client, date_reclamation,nom_client,prenom_client,email_client, num_reclamation, objet_reclamation, message_reclamation, etat_reclamation, id_client 
            FROM reclamation NATURAL JOIN client WHERE objet_reclamation LIKE '%$rech%' ORDER BY date_reclamation DESC";


    $db = config::getConnexion();
    	try{
    	$liste=$db->query($sql);
    	return $liste;

    	}
    	catch (Exception $e){
    	 die('Erreur: '.$e->getMessage());
    	 }
    }

}
?>
