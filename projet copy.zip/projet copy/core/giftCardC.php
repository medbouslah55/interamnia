<?PHP
	
	class GiftCardC extends PromotionC{
       


		
        function ajouterGiftCard($giftcard)
        {   
			$sql="insert into giftcard (id_giftcard,code_giftcard,valeur_giftcard,validite,id_clientcard) 
			values (:id, :code,:valeur,:v,:client)";
			
			$sql2="insert into notification (objet_not,temps_not,id_clientnot) 
			values (:obj,:t,:cl)";
			$db = config::getConnexion();
			try{
				$id=parent::ajouterPromotion($giftcard);
				$req=$db->prepare($sql);
				$req2=$db->prepare($sql2);
				
                $code=$giftcard->getCode();
				$valeur=$giftcard->getValeur();
				$validite=$giftcard->getValidite();
                $client=$giftcard->getClient();
				
				
				$req->bindValue(':id',$id);
                $req->bindValue(':code',$code);
				$req->bindValue(':valeur',$valeur);
				$req->bindValue(':v',$validite);
				$req->bindValue(':client',$client);

                 $daten=date("Y-m-d H:i:s");
				$req2->bindValue(':obj',"vous avez une nouvelle Gift card");
				$req2->bindValue(':t',$daten);
                $req2->bindValue(':cl',$client);
                
                
				$req->execute();
				$req2->execute();
			
			}
			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}
			
        }
        

      //jointure seulement fel classe fille?
      //supprimer du promo
		
        function afficherGiftCards()
        {
			//parent::afficherPromotion();
			$sql="SElECT p.id_promotion, p.date_deb, p.date_fin ,g.code_giftcard ,g.valeur_giftcard ,g.validite ,g.id_clientcard FROM giftcard g INNER JOIN promotion p ON (p.id_promotion=g.id_giftcard)";
			$db = config::getConnexion();
			try{
				$liste=$db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}	
		}
		
		function afficherGiftCardsval()
        {
			//parent::afficherPromotion();
			$sql="SElECT p.id_promotion, p.date_deb, p.date_fin ,g.code_giftcard ,g.valeur_giftcard ,g.validite ,g.id_clientcard FROM giftcard g INNER JOIN promotion p ON (p.id_promotion=g.id_giftcard) order by g.valeur_giftcard";
			$db = config::getConnexion();
			try{
				$liste=$db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}	
		}
		

		function afficherGiftCardsdate()
        {
			//parent::afficherPromotion();
			$sql="SElECT p.id_promotion, p.date_deb, p.date_fin ,g.code_giftcard ,g.valeur_giftcard ,g.validite ,g.id_clientcard FROM giftcard g INNER JOIN promotion p ON (p.id_promotion=g.id_giftcard) order by p.date_fin";
			$db = config::getConnexion();
			try{
				$liste=$db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}	
        }
        



        function supprimerGiftCard($id)
        {   
			$sql="DELETE FROM giftcard where id_giftcard= :id";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':id',$id);
			try{
				$req->execute();
				parent::supprimerPromotion($id);
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}

        }
        




        function modifierGiftCard($giftcard, $id)
        {   //var_dump($giftcard);  
			parent::modifierPromotion($giftcard, $id);
			$sql="UPDATE giftcard SET  code_giftcard=:code , valeur_giftcard=:valeur , id_clientcard=:client , validite=:validite WHERE id_giftcard=:id";
			
			var_dump($sql);
			
			$db = config::getConnexion();
			try{
				$req=$db->prepare($sql);
				
				$code=$giftcard->getCode();
                $valeur=$giftcard->getValeur();
				$validite=$giftcard->getValidite();
                $client=$giftcard->getClient();
				
				

				$req->bindValue(':id',$id);
				
				$datas = array(':id'=>$id, ':code'=>$code , ':valeur'=>$valeur, ':client'=>$client);
				
				
                $req->bindValue(':code',$code);
				$req->bindValue(':valeur',$valeur);
				$req->bindValue(':validite',$validite);
                $req->bindValue(':client',$client);
				
				

				var_dump($req);

			
				$req->execute();
                echo " Les datas : " ;
                print_r($datas);
				echo $req->rowCount() . " records UPDATED successfully";
				
			}
			catch (PDOException $e){
				echo " Erreur ! ".$e->getMessage();
				echo " Les datas : " ;
				print_r($datas);
			}
        }
        

   //a verifier comme afficher

        function recupererGiftCard($id)
        {
			$sql="SELECT p.id_promotion, p.date_deb, p.date_fin ,g.code_giftcard ,g.valeur_giftcard ,g.validite ,g.id_clientcard FROM giftcard g INNER JOIN promotion p ON (p.id_promotion=g.id_giftcard) where id_giftcard=$id";
			$db = config::getConnexion();
			try{
				$liste=$db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		
		




		 function recupererGiftCardClient($id)
        {
			$sql="SELECT p.id_promotion, p.date_deb, p.date_fin ,g.code_giftcard ,g.valeur_giftcard ,g.validite ,g.id_clientcard FROM giftcard g INNER JOIN promotion p ON (p.id_promotion=g.id_giftcard) where id_clientcard=$id";
			$db = config::getConnexion();
			try{
				$liste=$db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}


		
		



		function recherchermail($mail)
		{     var_dump($mail);
			$sql="SELECT id_client FROM client where email_client=$mail";
			$db = config::getConnexion();
			try{
				$liste=$db->query($sql);
				return $liste;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}




		function offrirGiftCard($id,$idclient)
        {   
			$sql="UPDATE giftcard SET id_clientcard=:idc WHERE id_giftcard=:id";
			
			
			
			$db = config::getConnexion();
			try{
				$req=$db->prepare($sql);
				
				
				$datas = array(':id'=>$id, ':idc'=>$idclient);
				$req->bindValue(':id',$id);

				$req->bindValue(':idc',$idclient);
				
			
				var_dump($req);

			
				$req->execute();
                echo " Les datas : " ;
                print_r($datas);
				echo $req->rowCount() . " records UPDATED successfully";
                
				
			}
			catch (PDOException $e){
				echo " Erreur ! ".$e->getMessage();
				echo " Les datas : " ;
				print_r($datas);
				
			}
        }






        
        


   function rechercherListeGiftcards($id)
          {
              $sql="SELECT p.id_promotion, p.date_deb, p.date_fin ,g.code_giftcard ,g.valeur_giftcard ,g.validite ,g.id_clientcard FROM giftcard g INNER JOIN promotion p ON (p.id_promotion=g.id_giftcard) where id_promotion like '%$id%'";
              $db = config::getConnexion();
              try{
                  $liste=$db->query($sql);
                  return $liste;
              }
              catch (Exception $e){
                  die('Erreur: '.$e->getMessage());
              }
          }

	function afficherClients(){
            
		$sql="SElECT * From client";
		$db = config::getConnexion();
		try{
			$liste=$db->query($sql);
			return $liste;
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}





	function afficherAdmins(){
            
		$sql="SElECT * From admin";
		$db = config::getConnexion();
		try{
			$liste=$db->query($sql);
			return $liste;
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}






	function afficherClientsfideles(){
            
		$sql="SELECT c.id_cmde,cl.prenom_client,SUM(c.prix_commande) FROM commande c ,client cl where cl.id_client=c.id_cmde group by id_cmde HAVING SUM(prix_commande)>20 ORDER BY SUM(prix_commande) DESC";
		$db = config::getConnexion();
		try{
			$liste=$db->query($sql);
			return $liste;
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}


     
	function statGiftcard(){
            
		$sql="SElECT id_clientcard, count(*) as total from giftcard group by id_clientcard limit 10";
		$db = config::getConnexion();
		try{
			$liste=$db->query($sql);
			return $liste;
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}




	function cstatGiftcard(){
            
		$sql="SElECT id_clientcard, count(*) as total from giftcard group by id_clientcard order by total desc limit 1 ";
		$db = config::getConnexion();
		try{
			$liste=$db->query($sql);
			return $liste;
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}





	function highestGiftcard(){
            
		$sql="SElECT p.id_promotion,g.valeur_giftcard ,g.id_clientcard FROM giftcard g INNER JOIN promotion p ON (p.id_promotion=g.id_giftcard) order by g.valeur_giftcard desc limit 1 ";
		$db = config::getConnexion();
		try{
			$liste=$db->query($sql);
			return $liste;
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}





	function afficherNotifications($id){
            
		$sql="SElECT * From notification where id_clientnot=$id";
		$db = config::getConnexion();
		try{
			$liste=$db->query($sql);
			return $liste;
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}





	function affichernumNotifications($id){
            
		$sql="SElECT count(*) From notification group by id_clientnot having id_clientnot=$id";
		$db = config::getConnexion();
		try{
			$liste=$db->query($sql);
			return $liste;
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}







	function suppnot($id)
	{   
		$sql="DELETE FROM notification where id_not= :id";
		$db = config::getConnexion();
		$req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
			$req->execute();
			
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}

	}







	}

?>
