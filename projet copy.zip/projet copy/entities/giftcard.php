
<?php

class GiftCard extends Promotion
{
   private $code;
   private $val;
   private $validite;
   private $client;
   function __construct($ddep,$dfin,$code,$valeur,$validite,$client)
   {
     parent::__construct($ddep,$dfin);
     $this->code=$code;
     $this->val=$valeur;
     $this->validite=$validite;
     $this->client=$client;
   }

   function getCode()
   {
      return $this->code; 
   }
   function getValidite()
   {
      return $this->validite; 
   }
   function getClient()
   {
      return $this->client; 
   }

   function setCode($code)
   {
       $this->code=$code;
   }
   function getValeur()
   {
      return $this->val; 
   }

   function setValeur($valeur)
   {
       $this->val=$valeur;
   }
}

?>