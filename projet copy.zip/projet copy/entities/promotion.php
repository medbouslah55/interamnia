<?PHP
	class Promotion{
		
		private $datedep;
		private $datefin;
		
		function __construct($ddep,$dfin){
			
			$this->datedep=$ddep;
			$this->datefin=$dfin;
			
		}
		
		
		function getDatedep(){
			return $this->datedep;
		}
		function getDatefin(){
			return $this->datefin;
		}
	
		function setDatedep($ddep){
			$this->datedep=$ddep;
		}
		function setDatefin($dfin){
			$this->datefin=$dfin;
		}
		
		
	}
?>