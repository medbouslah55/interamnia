
<?php

class Reduction extends Promotion
{
   private $pourcentage;
   private $prod;
   function __construct($ddep,$dfin,$pourcentage,$prod)
   {  
     parent::__construct($ddep,$dfin);
     $this->pourcentage = $pourcentage;
     $this->prod=$prod;
     
   }

   function getProduit()
   {
      return $this->prod; 
   }

   function setProduit($prod)
   {
       $this->prod=$prod;
   }
   
   function getPourcentage()
   {
      return $this->pourcentage; 
   }

   function setPourcentage($pourcentage)
   {
       $this->pourcentage=$pourcentage;
   }

}

?>
