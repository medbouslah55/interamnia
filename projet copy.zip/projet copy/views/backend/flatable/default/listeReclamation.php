<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title></title>
     <style type="text/css">
        body
        {
            font-family: Arial;
            font-size: 10pt;
        }
        table
        {
            border: 1px solid #ccc;
            border-collapse: collapse;
        }
        table th
        {
            background-color: #F7F7F7;
            color: #333;
            font-weight: bold;
        }
        table th, table td
        {
            padding: 5px;
            border: 1px solid #ccc;
        }
    </style>
</head>
<body>
    <?PHP
        include "../../../../core/reclamationC.php";

        $ReclamationC=new ReclamationCore();
        $listeReclamations=$ReclamationC->afficherReclamations();
    ?>
    <center>
     <table id="tblCustomers" cellspacing="0" cellpadding="0">
     <thead>
                                                                        <tr>
                                                                            <th>ID Reclamation</th>
                                                                            <th>ID client</th>
                                                                            <th>Date</th>
                                                                            <th>Nom et Prenom</th>
                                                                            <th>Email</th>
                                                                            <th>telephone</th>
                                                                            <th>Objet</th>
                                                                            <th>Message</th>
                                                                            <th>Etat</th>
                                                                            
                                                                            
                                                                        </tr>
                                                                        </thead>
                                                                        <tbody>                                                                                                                                                                                                                                                                                                        
                                                                            <?PHP
                                                                        foreach($listeReclamations as $row){
                                                                        
                                                                        ?>
                                                                        <tr>
                                                                            <td><?PHP echo $row['id_reclamation']; ?></td>
                                                                            <td><?PHP echo $row['id_client']; ?></td> 
                                                                            <td><?PHP echo $row['date_reclamation']; ?></td>
                                                                            <td><?PHP echo $row['nom_client'].' '.$row['prenom_client']; ?></td>
                                                                            <td><?PHP echo $row['email_client']; ?></td>
                                                                            <td><?PHP echo $row['num_reclamation']; ?></td>
                                                                            <td><?PHP echo $row['objet_reclamation']; ?></td>
                                                                            <td><?PHP echo $row['message_reclamation']; ?></td>
                                                                            <td><?PHP echo $row['etat_reclamation']; ?></td>
                                                                                                                                             
                                                                        </tr>
                                                                        <?PHP
                                                                    }

                                                                    ?>
                                                                        </tbody>
    </table>
                                                                
    <br />
    <input type="button" id="btnExport" value="Export" onclick="Export()" />
    </center>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
    <script type="text/javascript">
        function Export() {
            html2canvas(document.getElementById('tblCustomers'), {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("ListeReclamation.pdf");
                }
            });
        }
    </script>
</body>
</html>