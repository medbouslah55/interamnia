<?PHP
    include "../../../../config.php";
	  include "../../../../core/promotionC.php";
      include "../../../../core/reductionC.php";
      include "../../../../entities/promotion.php";
      include "../../../../entities/reduction.php";

	$reductionC=new ReductionC();
   // echo "1";
    
	if (isset($_POST['id'])){
       
		$reductionC->supprimerReduction($_POST["id"]);
		header('Location: index.php');
    }
    

?>

