<?php

include "../../../../config.php";
include "../../../../entities/promotion.php";
include "../../../../core/promotionC.php";
include "../../../../core/reductionC.php";

include "../../../../entities/reduction.php";



$reduction = new ReductionC();

$listeReductions = $reduction->rechercherListeReductions($_GET["q"]);

?>
<html>
<!-- <script>
function printDiv(divName,dated) {
     var printContents = divName+dated;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
</script> -->
<body>
<div class="col-lg-12">
<div class="row">
<div class="col-lg-12">
<div class="card table-1-card">
<div class="card-block">
<div class="table-responsive">
<table class="table">
<thead>
<tr class="text-capitalize">
<th>identifiant</th>
  <th>date debut</th>
  <th>date fin</th>
  
  <th>pourcentage</th>
  <th>produit</th>
  
  <th>imprimer</th>
  
</tr>
</thead>
<tbody>
<?php
foreach($listeReductions as $row) {
   
?>
<tr>
<td><?php echo $row['id_promotion']; ?></td>
<td><?php echo $row['date_deb']; ?></td>
<td><?php echo $row['date_fin']; ?></td>
<td><?php echo $row['pourcentage_reduction']; ?></td>
<td><?php echo $row['id_prodred']; ?></td>



<td>
<button type="submit" onclick="printDiv('<?php echo $row['id_promotion']; ?>','<?php echo $row['date_deb']; ?>','<?php echo $row['date_fin']; ?>','<?php echo $row['pourcentage_reduction']; ?>','<?php echo $row['id_prodred']; ?>')" value="imprimer info" class="btn btn-success btn-outline-success" >
<i class="ti-arrow-down"></i>
imprimer info
</button>
</td>

</tr>



<?php
}

?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>

</body>
</html>
