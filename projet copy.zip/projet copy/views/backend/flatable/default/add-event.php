<?php
 
 require_once "../../../../config.php";
include "../../../../core/promotionC.php";
include "../../../../core/reductionC.php";
include "../../../../entities/promotion.php";
include "../../../../entities/reduction.php";
$title = isset($_POST['title']) ? $_POST['title'] : "";
    $pourc= isset($_POST['pourc']) ? $_POST['pourc'] : "";
$start = isset($_POST['start']) ? $_POST['start'] : "";
$end = isset($_POST['end']) ? $_POST['end'] : "";
   
$reduction=new Reduction($start,$end,$pourc,$title);
            
        
        $reductionC=new ReductionC();
        
        $reductionC->ajouterReduction($reduction);
?>
