<?PHP
include "../../../../config.php";
	include "../../../../core/promotionC.php";
    include "../../../../core/giftCardC.php";
    include "../../../../entities/promotion.php";
    include "../../../../entities/giftcard.php";

	$cardC=new GiftCardC();
   
	if (isset($_POST['id'])){
        echo "2";
		$cardC->supprimerGiftCard($_POST["id"]);
		header('Location: afficherGiftcard.php');
    }
    

?>
