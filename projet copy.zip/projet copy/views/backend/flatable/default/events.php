<?php

include "../../../../config.php";
include "../../../../entities/promotion.php";
include "../../../../core/promotionC.php";
include "../../../../core/reductionC.php";

include "../../../../entities/reduction.php";

 

$reduction = new ReductionC();

$resultset=$reduction->calendarReduction();

$calendar = array();
foreach($resultset as $row) {

$calendar[] = array(
'id' =>$rows['id_promotion'],
'title' => $rows['id_prodred'],
'url' => "#",
"class" => 'event-important',
'start' => $rows['date_deb'],
'end' => $rows['date_fin']
);
}
$calendarData = array(
"success" => 1,
"result"=>$calendar);
echo json_encode($calendarData);
?>
