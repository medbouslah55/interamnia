<?php

include "../../../../config.php";

include "../../../../entities/promotion.php";
include "../../../../core/promotionC.php";


include "../../../../entities/giftcard.php";
include "../../../../core/giftCardC.php";

$giftcard = new GiftCardC();

$u = $giftcard->afficherAdmins();

if (isset($_POST['login']) && isset($_POST['mdp']))
{
    
foreach($u as $t){
if ($t['email_admin'] == $_POST['login'] && $t['mdp_admin'] == $_POST['mdp']){
    session_start();
$_SESSION['l'] = $_POST['login']; 
 $_SESSION['p'] = $_POST['mdp']; 
  $_SESSION['id'] = $t['id_admin']; 
  
header("location:index.php") ;


}

}

}
else
echo "champs vide";
?>