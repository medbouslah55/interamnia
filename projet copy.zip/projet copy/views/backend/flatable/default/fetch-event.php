<?php
    require_once "../../../../config.php";
include "../../../../core/promotionC.php";
include "../../../../core/reductionC.php";
include "../../../../entities/promotion.php";
include "../../../../entities/reduction.php";
    $json = array();
    $date=date("Y-m-d");
    $sqlQuery = "SELECT r.id_reduction as id , r.id_prodred as title , p.date_deb as start , p.date_fin as end  FROM reduction r INNER JOIN promotion p ON (p.id_promotion=r.id_reduction) where p.date_fin>$date";

    $db = config::getConnexion();
            try{
                $result=$db->query($sqlQuery);
                $eventArray = array();
                  foreach($result as $row) {
                       array_push($eventArray, $row);
                   }
                   

                   
                   echo json_encode($eventArray);
                
            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }
    
   
   
?>
