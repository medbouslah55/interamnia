<?php
include "../../../../config.php";
include "../../../../entities/promotion.php";
include "../../../../core/promotionC.php";
include "../../../../core/reductionC.php";

include "../../../../entities/reduction.php";

 

$reduction = new ReductionC();

$listeReductions =$reduction->statReduction();

foreach ($listeReductions as $row) {
    $data[] = $row;
  }
  print json_encode($data);

?>
