<?php
    include "../../../../config.php";
      include "../../../../entities/promotion.php";
      include "../../../../core/promotionC.php";
      include "../../../../core/giftCardC.php";
     

      include "../../../../entities/giftcard.php";


$giftcard = new GiftCardC();

$listeGiftcards = $giftcard->rechercherListeGiftcards($_GET["q"]);

?>
<html>
<!-- <script>
function printDiv(divName,dated) {
     var printContents = divName+dated;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
</script> -->
<body>
<div class="col-lg-12">
<div class="row">
<div class="col-lg-12">
<div class="card table-1-card">
<div class="card-block">
<div class="table-responsive">
<table class="table">
<thead>
<tr class="text-capitalize">
<th>identifiant</th>
  <th>date debut</th>
  <th>date fin</th>
  
  <th>code</th>
  <th>valeur</th>
  <th>client</th>
  <th>validite</th>
  
  <th>imprimer</th>
  
</tr>
</thead>
<tbody>
<?php
foreach($listeGiftcards as $row) {
   
?>
<tr>
<td><?php echo $row['id_promotion']; ?></td>
<td><?php echo $row['date_deb']; ?></td>
<td><?php echo $row['date_fin']; ?></td>
<td><?php echo $row['code_giftcard']; ?></td>
    <td><?php echo $row['valeur_giftcard']; ?></td>
    <td><?php echo $row['id_clientcard']; ?></td>
    <td><?php echo $row['validite']; ?></td>



<td>
<input type="button" onclick="printDiv('<?php echo $row['id_promotion']; ?>','<?php echo $row['date_deb']; ?>','<?php echo $row['date_fin']; ?>','<?php echo $row['code_giftcard']; ?>','<?php echo $row['valeur_giftcard']; ?>','<?php echo $row['id_clientcard']; ?>','<?php echo $row['validite']; ?>')" value="imprimer info" />
</td>

</tr>



<?php
}

?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>

</body>
</html>
