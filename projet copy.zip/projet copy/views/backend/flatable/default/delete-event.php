<?php
 require_once "../../../../config.php";
include "../../../../core/promotionC.php";
include "../../../../core/reductionC.php";
include "../../../../entities/promotion.php";
include "../../../../entities/reduction.php";
    $id = $_POST['id'];
$reduction=new ReductionC();
    
$reduction->supprimerReduction($id);
echo "<script>location.replace('calendarReduction.php');</script>";
?>

