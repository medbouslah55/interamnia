<?php

include "../../config.php";

include "../../entities/promotion.php";
include "../../core/promotionC.php";


include "../../entities/giftcard.php";
include "../../core/giftCardC.php";

$giftcard = new GiftCardC();

$u = $giftcard->afficherClients();

if (isset($_POST['login']) && isset($_POST['mdp']))
{
    
foreach($u as $t){
if ($t['email_client'] == $_POST['login'] && $t['mdp_client'] == $_POST['mdp']){
    session_start();
$_SESSION['l'] = $_POST['login']; 
 $_SESSION['p'] = $_POST['mdp']; 
  $_SESSION['id'] = $t['id_client']; 
  
header("location:listeGiftcard.php") ;


}

}

}
else
echo "champs vide";
?>