   
                        <?php
                        include "../../config.php";

                        include "../../entities/promotion.php";
                        include "../../core/promotionC.php";
                        
                        
                        include "../../entities/giftcard.php";
                        include "../../core/giftCardC.php";
                        
                        $giftcard = new GiftCardC();
                           if (isset($_POST['iddn']))
                           {  echo "ici";
                            $giftcard->suppnot($_POST['iddn']);
                            header('location:notification.php');

                           }




                       ?>