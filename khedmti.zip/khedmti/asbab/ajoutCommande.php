<?PHP
include "./entiter/commande/commande.php";
include "./core/commande/commandeCore.php";

if (isset($_POST['cin']) and isset($_POST['nom']) and isset($_POST['prenom']) and isset($_POST['nbH']) and isset($_POST['tarifH'])){
$employe1=new employe($_POST['cin'],$_POST['nom'],$_POST['prenom'],$_POST['nbH'],$_POST['tarifH']);
$employe1Controller=new EmployeController();
$employe1Controller->ajouterEmploye($employe1);
	
}else{
	echo "vérifier les champs";
}

?>